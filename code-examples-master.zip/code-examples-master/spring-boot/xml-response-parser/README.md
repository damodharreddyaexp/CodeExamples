# Parsing XML Response in Spring Boot

For step-by-step instructions, please visit [blog post](https://attacomsian.com/blog/parsing-xml-response-spring-boot).
