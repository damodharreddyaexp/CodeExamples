# Spring integration with Spring Boot

Example of Stripe payments integration with Spring Boot.

For step-by-step instructions, please visit [blog post](https://attacomsian.com/blog/stripe-integration-with-spring-boot).
