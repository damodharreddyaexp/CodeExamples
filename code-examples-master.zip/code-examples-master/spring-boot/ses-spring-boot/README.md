# ses-spring-boot
Example of Amazon SES integration with Spring Boot.

For step-by-step instructions, please visit [blog post](
https://attacomsian.com/blog/amazon-ses-integration-with-spring-boot/).
