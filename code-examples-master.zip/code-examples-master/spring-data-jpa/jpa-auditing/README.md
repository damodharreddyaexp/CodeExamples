# Spring Data JPA Auditing using Spring Boot and MySQL

For step-by-step instructions, please check out [blog post](https://attacomsian.com/blog/spring-data-jpa-auditing).
